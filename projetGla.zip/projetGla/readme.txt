Dans cette parties les mod�les Ville, Route et Tron�on ont �t� cr��s pour manipuler les donn�es de notre fichier xml.

*Les m�thodes de ville
getNom pour avoir le nom d'une ville
getType pour avoir le type d'une ville
getTouristique pour savoir si la ville est touristique
getLongitude // // la longitude
getLatitude // // la latitude

*Les methodes de route
Constructeur Route(String nom,String type) 
getNom pour avoir le nom de la route
getType // // le type de la route
ArrayList<Troncon> getTroncon() retourne les troncons appartenant a la route

*Les methodes de Troncon
Constructeur Troncon(String ville1, String ville2,Integer vitesse, Integer longueur, String touristique, String radar, String payant)
boolean is(String ville) pour savoir si une ville appartient a ce tron�on
String getville1() pour avoir la ville de d�part du tron�on
String getville2() // // d'arriv�e du tron�on
Integer getVitesse () // // la vitesse autoris�e
boolean getTouristique ()  savoir si le tron�on est touristique
boolean getRadar () savoir si il comporte des radars
boolean getPayant () savoir si il est payant


