package projetGla;	

import java.util.ArrayList;

public class Route {
	String nom, type;
	//la liste des troncons dans un tableau
	ArrayList<Troncon> Troncons;
	
	public Route(String nom,String type) {
		this.nom=nom;
		this.type=type; 
	}
	public String  getNom() {
		return this.nom;
	}
	public String getType() {
		return this.type;
	}
	
	public ArrayList<Troncon> getTroncon(){
		return Troncons;
	}
}
