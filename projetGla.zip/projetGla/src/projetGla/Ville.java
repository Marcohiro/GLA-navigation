package projetGla;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class Ville {
	private String nom, type, touristique;
	private Float longitude, latitude;
	private ArrayList<Troncon> troncons;
	public Ville(String nom, String type,String touristique, Float longitude, Float latitude) {
		           this.nom = nom;
		           this.type=type;
		           this.touristique=touristique;
		           this.longitude=longitude;
		           this.latitude=latitude;
	}
	public String toString() {
		return this.nom + " type: " + this.type + ", touristique :" + this.touristique + ", longitude:" + this.longitude + ", latitude:" + this.latitude;
		
	}
	
	public String getNom() {
		return this.nom;
	}
	
	public String getType() {
		return this.type;
	}
	public boolean getTouristique() {
		if(this.touristique=="oui") {
			return true;
		}else {
			return false;
		}
	}
	public Float getLongitude() {
		return this.longitude;
	}
	public Float getLatitude() {
		return this.latitude;
	}
	
	//les tron�ons qui contiennent la ville
	public ArrayList<Troncon> listeTroncons(){
		
		return this.troncons;
		
	}
	
	
}
