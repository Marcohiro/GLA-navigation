package projetGla;
public class Troncon {
	
	//les deux villes sur le tron�on
	String ville1, ville2;
	
	//vitesse autoris� et longueur du tron�on
	Integer vitesse, longueur;
	String touristique, radar, payant;
	//Constructeurs
	public Troncon(String ville1, String ville2,Integer vitesse, Integer longueur, String touristique, String radar, String payant) {
		this.ville1=ville1;
		this.ville2=ville2;
		this.vitesse=vitesse;
		this.longueur=longueur;
		this.touristique=touristique;
		this.radar=radar;
		this.payant=payant;
	}
	//Determine si la ville est dans le tron�on
	public boolean is(String ville) {
		return (ville==ville1 || ville==ville2);
	}
	
	public String getville1() {
		return this.ville1;
	}
	public String getville2() {
		return this.ville2;
	}
	public Integer getVitesse () {
		return this.vitesse;
	}
	public Integer getLongueur () {
		return this.longueur;
	}
	public boolean getTouristique () {
		return (this.touristique=="oui");
	}
	public boolean getRadar () {
		return (this.radar=="oui");
	}
	public boolean getPayant () {
		return (this.payant=="oui");
	}
	
}
